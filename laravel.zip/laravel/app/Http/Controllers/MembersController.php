<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Member;

class MembersController extends Controller
{
    public function form(Request $request){
    	$members = Member::all();
  		return view('registration-form', compact('members'));
    }
    public function add(Request $request){
      $id = $request->id;
    	$first_name = $request->first_name;
    	$middle_name = $request->middle_name;
    	$last_name = $request->last_name;
    	$student_id = $request->student_id;
    	$program = $request->program;
    	$address = $request->address;

    	$member = new Member;
      $member->id = $id;
    	$member->first_name = $first_name;
   	  $member->middle_name = $middle_name;
		  $member->last_name = $last_name;
		  $member->student_id = $student_id;
  		$member->program = $program;
  		$member->address = $address;
  		$member->save();

  		return redirect('/members');		
    }
    public function editStud(Request $request, $id){
      $member = Member::find($id);
      return view('edit-student', compact('member'));
    }
    public function saveEdit(Request $request){
      $id = $request->id;
      $first_name = $request->first_name;
      $middle_name = $request->middle_name;
      $last_name = $request->last_name;
      $student_id = $request->student_id;
      $program = $request->program;
      $address = $request->address;

      $member = Member::find($id);
      $member->id = $id;
      $member->first_name = $first_name;
      $member->middle_name = $middle_name;
      $member->last_name = $last_name;
      $member->student_id = $student_id;
      $member->program = $program;
      $member->address = $address;
      $member->save();

      return redirect('/members');     
    }
    public function deletestudent(Request $request, $id){
      $member = Member::find($id);
      $member->delete();
      return redirect('/members');
    }
}
