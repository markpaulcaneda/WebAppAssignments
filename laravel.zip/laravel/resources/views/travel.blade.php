<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset=utf-8>
	<meta name=description content="">
	<meta name=viewport content="width=device-width, initial-scale=1">
	<title>Travel And Adventure</title>
	<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.theme.css">
	<link rel="stylesheet" type="text/css" href="Bootstrap/css/travel.css">

</head>
<body>

<nav id="nav">	
</nav>

<div id="view">
  <span style="background-color:black;width:500px;height:100px;margin-top:300px">
  	
  </span>
    <img src="Img/mountain.jpg" alt="" class="c">
 	
</div>

<div class="field">
	<p>
	Middle Space
	</p>
</div>





</body>
</html>