<!DOCTYPE html>
<html lang="en">
<head>
<meta charset=utf-8>
<meta name=description content="">
<meta name=viewport content="width=device-width, initial-scale=1">
	<title>Edit Student</title>
<link rel="stylesheet" type="text/css" href="public/Bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="public/Bootstrap/css/bootstrap.theme.css">
<link rel="stylesheet" type="text/css" href="Bootstrap/css/stylesheet.css">
<link rel="shortcut icon" href="{{ URL::asset('Img/form_icon.png') }}">
<script src="Bootstrap/js/bootstrap.min.js"></script>

<style>
body{
	background-size: cover;
	background-position: center center;
	background-repeat: no-repeat;
	background-attachment: fixed;
	background-image: 
}

.form {
	border: 1px black;
	border-radius: 15px;
	width: 35%;
	margin-left: 330px;
	margin-top: 60px;
	background-color: #303331;
	opacity: 0.9;
	background-attachment: fixed;
}
.form-horizontal {
	width: 250px;
	margin-left: 88px;
	margin-top: 20px;
}
.form-horizontal input{
	text-align: center;
	padding: 12px 20px;
	display: inline-block;
	margin: 11px 0;
	border: 1px solid #ccc;
	border-radius: 4px;
	box-sizing: border-box;
	height: 35px;
	color: black;
	font-size: 13px;
	cursor: pointer;
	background-color: #f7f7ca;
	font-family: Goudy old style;
}
.btn-success{
	margin-bottom: 30px;
	width: 40%;
	cursor: pointer;
	font-size: 13px;
	background-color: #3ed64d;
	font-size: 17px;
	font-family: Goudy old style;
	padding: 7px 20px;
	margin: 12px 0;
	border: 1px;
	border-radius: 6px;
	box-sizing: border-box;
	color: white;
	position: relative;
	margin-left: 39px;

}
.btn-success:hover{
	background-color: green;
}

.back{
	position: fixed;
	top: 0;
	left: 0;
	z-index: -1;
	width: 100%;
	height: 100%;
}
</style>

</head>
<body>
<img src="{{ URL::asset('Img/bg.jpg') }}" class="back">
<div class="form"><br>
<form method="POST" action="/save-edit" class="form-horizontal">
{{ csrf_field() }}
	<input type="text" name="id" value="{{ $member->id }}" class="form-control" hidden>
	<input type="text" name="first_name" value="{{ $member->first_name }}" class="form-control"><br>
	<input type="text" name="middle_name" value="{{ $member->middle_name }}" class="form-control"><br>
	<input type="text" name="last_name" value="{{ $member->last_name }}" class="form-control"><br>
	<input type="text" name="student_id" value="{{ $member->student_id }}" class="form-control"><br>
	<input type="text" name="program" value="{{ $member->program }}" class="form-control"><br>
	<input type="text" name="address" value="{{ $member->address }}" class="form-control"><br>
	<button type="submit" class="btn btn-success">Save</button>
</form>
</div>

</body>
</html>