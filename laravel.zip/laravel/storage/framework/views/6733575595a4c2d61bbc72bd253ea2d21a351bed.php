<!DOCTYPE html>
<html lang="en">
<head>
	<title>Registration Form</title>
	<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap-theme.min.css">
	<link rel="stylesheet" type="text/css" href="CSS/style.css">
</head>
<body>
<div id="banner">
	<img src="Img/icon2.png" alt="icon" class="img-responsive">
	<p>WELCOME TO STUDENT REGISTRATION FORM</p>

<div class="testbox">
	<form method="POST" action="processRegistration">
		<?php echo e(csrf_field()); ?>


		<tr>
			<td>
			 	<input type="text" name="first_name" placeholder="First Name" required>
			</td>
		</tr>
		<br>
		<tr>
			<td>
				<input type="text" name="middle_name" placeholder="Middle Name" required> 
			</td>
		</tr>
		<br>
		<tr>
			<td>
			 	<input type="text" name="last_name" placeholder="Last Name" required>
			</td>
		</tr>
		<br>
		<tr>
			<td>
				<input type="text" name="student_id" placeholder="Student ID" required> 
			</td>
		</tr>
		<br>
		<tr>
			<td>
			 	<input type="text" name="program" placeholder="Program" required>
			</td>
		</tr>
		<br>
		<tr>
			<td>
				<input type="text" name="address" placeholder="Address" required> 
			</td>
		</tr>
		<br><br>
		<div class="sign">
		<input type="Submit" name="Register" class="btn btn-primary btn-block">
	</form>
	</div>
</div>
</div>	
</form>
</body>
</html>