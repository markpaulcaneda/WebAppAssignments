<!DOCTYPE html>
<html lang="en">
<head>
<meta charset=utf-8>
<meta name=description content="">
<meta name=viewport content="width=device-width, initial-scale=1">
<title>Registration Form</title>
<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.theme.css">
<link rel="stylesheet" type="text/css" href="Bootstrap/css/stylesheet.css">
<link rel="stylesheet" type="text/css" href="{{ URL::asset('font-awesome/css/font-awesome.min.css') }}">
<link rel="shortcut icon" href="Img/form_icon.png">
<script src="Bootstrap/js/bootstrap.min.js"></script>
<script src="Bootstrap/js/jquery.min.js"></script>
<script src="Bootstrap/js/modal.js"></script>

</head>
<body background="Img/bg.jpg">
<div class="nav">
	<img src="Img/laverdad.png" class="laverdad">
		<h2 class="lvcc">La Verdad Christian College<br>Registration Form</h2>	

<style>
.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
}
img.avatar {
    width: 30%;
    border-radius: 50%;
    background-color:solid black;

}
.close {
    position: absolute;
    margin-left: 170px;
    color: #000;
    font-size: 25px;
    font-weight: bold;
}
.close:hover,
.close:focus {
    color: red;
    cursor: pointer;
}
.form-horizontal {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
}
@-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)}
    to {-webkit-transform: scale(1)}
}
    
@keyframes animatezoom {
    from {transform: scale(0)}
    to {transform: scale(1)}
}
#reg{
	margin-left: 850px;
	margin-top: 17px;
}

</style>

</head>
<body>
<button onclick="document.getElementById('id01').style.display='block'" class="btn btn-primary" id="reg">Register</button>
<div id="id01" class="modal">
  <form class="form-horizontal" action="/add" method="post">
{{ csrf_field() }}
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="Img/avatar.png" class="avatar"><br><br><br>
      <input type="text" placeholder="Enter Firstname" name="first_name" required>
      <input type="text" placeholder="Enter Middlename" name="middle_name" required>
      <input type="text" placeholder="Enter Lastname" name="last_name" required>
      <input type="text" placeholder="Enter StudentID" name="student_id" required>
      <input type="text" placeholder="Enter Program" name="program" required>
      <input type="text" placeholder="Enter Address" name="address" required><br><br>
      <button type="submit" class="btn btn-success">Submit</button>
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="btn btn-warning">Cancel</button>
    </div>
  </form>
</div>

<script>
var modal = document.getElementById('id01');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

</div>

<br>
<br>
<table class="table table-bordered table-hover">
	<tr class="table-hover" style="background-color:green;color:white">
		<th hidden >ID</th>
		<th> Student ID </th>
		<th> Name </th>
		<th> Program </th>
		<th> Address </th>
		<th> Options</th>
	</tr>
	@foreach ($members as $member)
	<tr>
		<td hidden>{{ $member->id }}</td>
		<td>{{ $member->student_id }}</td>
		<td>
			<?php
				echo $member->first_name." ".$member->middle_name." ".$member->last_name; 
			?>
		</td>
		<td>{{ $member->program }}</td>
		<td>{{ $member->address }}</td>
		
		<td>
			<a href="/edit/{{ $member->id }}">
				<button class="btn btn-primary"><i class="fa fa-pencil" aria-hidden="true">Edit</i></button>
			</a>
			<a href="/delete/{{ $member->id }}">
				<button class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true">Soft Delete</i></button>
			</a>
		</td>
	@endforeach
</table>
</body>
</html>

