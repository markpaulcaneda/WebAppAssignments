<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Travel;

class TravelController extends Controller
{
    public function site(Request $request){
    	$travels = Travel::all();
    	return view('travel', compact('travels'));
    }
}
