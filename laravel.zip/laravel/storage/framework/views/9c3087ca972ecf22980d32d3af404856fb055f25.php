<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset=utf-8>
	<meta name=description content="">
	<meta name=viewport content="width=device-width, initial-scale=1">
	<title>Registration Complete</title>
	<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap-theme.min.css">


<style>
	body{
		background-color: lightgray;
	}
	.a{
		background-color: grey;
	}
	.b{
		background-color: lightgreen;
	}
	table, thead, th, td, tr{
		border: 1px solid black;
	}
</style>

</head>
<body>
<div class="container">
 <h1>REGISTRATION COMPLETE</h1>

<table class="table">
	<thead>
		<tr class="b">
			<th>First Name</th>
			<th>Middle Name</th>
			<th>Last Name</th>
			<th>Student ID</th>
			<th>Program</th>
			<th>Address</th>
		</tr>
	</thead>
	<tbody>
		<tr class="a">
			<td class="Success"><?php echo e($first_name); ?></td>
			<td class="success"><?php echo e($middle_name); ?></td>
			<td><?php echo e($last_name); ?></td>
			<td class="danger"><?php echo e($student_id); ?></td>
			<td><?php echo e($program); ?></td>
			<td class="info"><?php echo e($address); ?></td>
		</tr>

	</tbody>
</table>	
</div>
</body>
</html>