<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<h1>COMPLETE</h1>

<table>
	<thead>
		<tr>
			<th>FIRST NAME</th>
			<th>MIDDLE NAME</th>
			<th>LAST NAME</th>
			<th>STUDENT ID</th>
			<th>PROGRAM</th>
			<th>ADDRESS</th>
		</tr>
	</thead>

	<tbody>
	@foreach ($members as $member)
		<tr>
			<td>{{ $member->first_name }}</td>
			<td>{{ $member->middle_name }}</td>
			<td>{{ $member->last_name }}</td>
			<td>{{ $member->student_id }}</td>
			<td>{{ $member->program }}</td>
			<td>{{ $member->address }}</td>
		</tr>
	@endforeach
	</tbody>
</table>

</body>
</html>